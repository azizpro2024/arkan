
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Menu, X, Globe, Phone } from 'lucide-react';

const Navbar: React.FC = () => {
  const { lang, setLang, t } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white shadow-lg py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <div className="w-10 h-10 bg-[#006c35] flex items-center justify-center rounded-lg shadow-md">
            <span className="text-white font-bold text-xl">A</span>
          </div>
          <span className={`text-2xl font-bold tracking-tight ${isScrolled ? 'text-[#006c35]' : 'text-white'}`}>
            {lang === 'ar' ? 'أركان' : 'ARKAN'}
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
          <a href="#" className={`font-medium hover:text-[#d4af37] transition-colors ${isScrolled ? 'text-slate-700' : 'text-white'}`}>{t.featured}</a>
          <a href="#" className={`font-medium hover:text-[#d4af37] transition-colors ${isScrolled ? 'text-slate-700' : 'text-white'}`}>{t.cities}</a>
          <a href="#" className={`font-medium hover:text-[#d4af37] transition-colors ${isScrolled ? 'text-slate-700' : 'text-white'}`}>{t.aboutUs}</a>
          <button 
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className={`flex items-center space-x-1 rtl:space-x-reverse px-4 py-2 rounded-full border transition-all ${isScrolled ? 'border-[#006c35] text-[#006c35] hover:bg-[#006c35] hover:text-white' : 'border-white text-white hover:bg-white hover:text-slate-900'}`}
          >
            <Globe size={18} />
            <span className="text-sm font-semibold uppercase">{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>
          <a href="tel:+96612345678" className="bg-[#d4af37] text-white px-6 py-2.5 rounded-full font-bold shadow-lg hover:bg-[#b8952e] transition-transform active:scale-95 flex items-center space-x-2 rtl:space-x-reverse">
            <Phone size={18} />
            <span>{t.contactUs}</span>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X className={isScrolled ? 'text-slate-900' : 'text-white'} /> : <Menu className={isScrolled ? 'text-slate-900' : 'text-white'} />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-2xl py-6 px-4 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex flex-col space-y-4 text-center">
            <a href="#" className="text-lg font-bold text-slate-800">{t.featured}</a>
            <a href="#" className="text-lg font-bold text-slate-800">{t.cities}</a>
            <a href="#" className="text-lg font-bold text-slate-800">{t.aboutUs}</a>
            <button 
              onClick={() => { setLang(lang === 'ar' ? 'en' : 'ar'); setMobileMenuOpen(false); }}
              className="mx-auto flex items-center space-x-2 text-[#006c35] border border-[#006c35] px-6 py-2 rounded-full"
            >
              <Globe size={18} />
              <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
            </button>
            <a href="tel:+96612345678" className="bg-[#006c35] text-white py-3 rounded-xl font-bold">
              {t.contactUs}
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
