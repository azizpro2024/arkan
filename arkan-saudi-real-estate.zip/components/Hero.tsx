
import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Search, MapPin, Building, DollarSign } from 'lucide-react';

const Hero: React.FC = () => {
  const { t, lang } = useLanguage();

  return (
    <div className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-[10s] hover:scale-105"
        style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1580674285054-bed31e145f59?auto=format&fit=crop&q=80&w=1920)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-[#006c35]/30"></div>
      </div>

      <div className="container mx-auto px-4 z-10 text-center text-white mt-16">
        <h1 className="text-4xl md:text-7xl font-bold mb-6 tracking-tight animate-in fade-in slide-in-from-bottom-6 duration-700">
          {t.heroTitle}
        </h1>
        <p className="text-lg md:text-2xl mb-12 max-w-2xl mx-auto opacity-90 font-light animate-in fade-in slide-in-from-bottom-8 duration-1000">
          {t.heroSub}
        </p>

        {/* Search Bar */}
        <div className="max-w-5xl mx-auto bg-white/10 backdrop-blur-md p-4 rounded-3xl shadow-2xl border border-white/20 animate-in fade-in zoom-in duration-1000">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            
            <div className="relative">
              <div className="absolute inset-y-0 left-3 rtl:left-auto rtl:right-3 flex items-center pointer-events-none">
                <MapPin className="text-[#d4af37]" size={20} />
              </div>
              <input 
                type="text" 
                placeholder={t.city}
                className="w-full bg-white text-slate-900 pl-10 rtl:pr-10 pr-4 py-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#006c35]"
              />
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-3 rtl:left-auto rtl:right-3 flex items-center pointer-events-none">
                <Building className="text-[#d4af37]" size={20} />
              </div>
              <select className="w-full bg-white text-slate-900 pl-10 rtl:pr-10 pr-4 py-4 rounded-2xl appearance-none focus:outline-none focus:ring-2 focus:ring-[#006c35]">
                <option value="">{t.propertyType}</option>
                <option value="villa">{lang === 'ar' ? 'فيلا' : 'Villa'}</option>
                <option value="apartment">{lang === 'ar' ? 'شقة' : 'Apartment'}</option>
              </select>
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-3 rtl:left-auto rtl:right-3 flex items-center pointer-events-none">
                <DollarSign className="text-[#d4af37]" size={20} />
              </div>
              <select className="w-full bg-white text-slate-900 pl-10 rtl:pr-10 pr-4 py-4 rounded-2xl appearance-none focus:outline-none focus:ring-2 focus:ring-[#006c35]">
                <option value="">{t.priceRange}</option>
                <option value="1">1M - 2M</option>
                <option value="2">2M - 5M</option>
              </select>
            </div>

            <button className="bg-[#006c35] hover:bg-[#005128] text-white font-bold py-4 rounded-2xl transition-all flex items-center justify-center space-x-2 rtl:space-x-reverse shadow-lg group">
              <Search size={20} className="group-hover:scale-110 transition-transform" />
              <span>{t.search}</span>
            </button>
            
          </div>
        </div>
      </div>

      {/* Saudi Map Decoration (Subtle SVG) */}
      <div className="absolute bottom-10 right-10 md:right-20 opacity-10 pointer-events-none">
        <img src="https://upload.wikimedia.org/wikipedia/commons/4/4e/Flag_of_Saudi_Arabia.svg" className="w-64 grayscale invert" alt="Saudi Map Background" />
      </div>
    </div>
  );
};

export default Hero;
