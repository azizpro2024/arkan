
import React from 'react';
import { CITIES } from '../constants';
import { useLanguage } from '../context/LanguageContext';

const CityGrid: React.FC = () => {
  const { lang, t } = useLanguage();

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <span className="text-[#d4af37] font-bold uppercase tracking-widest text-sm">{lang === 'ar' ? 'استكشف المناطق' : 'Explore Regions'}</span>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mt-2">{t.cities}</h2>
          </div>
          <a href="#" className="text-[#006c35] font-bold flex items-center space-x-2 rtl:space-x-reverse mt-4 md:mt-0 hover:underline">
            <span>{t.viewAll}</span>
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {CITIES.map((city) => (
            <div 
              key={city.id} 
              className="relative h-64 rounded-3xl overflow-hidden group cursor-pointer"
            >
              <img 
                src={city.image} 
                alt={city.name[lang]} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 text-white text-center md:text-start">
                <h4 className="text-2xl font-bold mb-1">{city.name[lang]}</h4>
                <p className="text-sm opacity-80 font-medium">{city.count} {lang === 'ar' ? 'عقار' : 'Properties'}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CityGrid;
