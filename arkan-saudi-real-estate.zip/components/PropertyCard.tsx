
import React from 'react';
import { Property } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { Bed, Bath, Move, Heart } from 'lucide-react';

interface Props {
  property: Property;
  onSelect: (p: Property) => void;
}

const PropertyCard: React.FC<Props> = ({ property, onSelect }) => {
  const { lang, t } = useLanguage();

  return (
    <div 
      className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-slate-100 group cursor-pointer"
      onClick={() => onSelect(property)}
    >
      <div className="relative h-64 overflow-hidden">
        <img 
          src={property.images[0]} 
          alt={property.title[lang]} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4 flex space-x-2 rtl:space-x-reverse">
          <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase ${property.status === 'For Sale' ? 'bg-[#006c35] text-white' : 'bg-[#d4af37] text-white'}`}>
            {property.status === 'For Sale' ? t.sale : t.rent}
          </span>
          {property.featured && (
            <span className="bg-slate-900/80 backdrop-blur-sm text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase">
              {lang === 'ar' ? 'مميز' : 'Featured'}
            </span>
          )}
        </div>
        <button className="absolute top-4 right-4 bg-white/30 backdrop-blur-md p-2 rounded-full text-white hover:bg-white hover:text-red-500 transition-colors">
          <Heart size={18} />
        </button>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-slate-800 line-clamp-1">{property.title[lang]}</h3>
          <span className="text-[#006c35] font-bold text-lg whitespace-nowrap">
            {property.price.toLocaleString()} <span className="text-sm font-medium">{t.sar}</span>
          </span>
        </div>
        
        <p className="text-slate-500 text-sm mb-4 line-clamp-1 flex items-center space-x-1 rtl:space-x-reverse">
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]"></span>
          <span>{property.city[lang]}</span>
        </p>

        <div className="flex items-center justify-between pt-4 border-t border-slate-50">
          {property.beds && (
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-slate-600">
              <Bed size={18} className="text-slate-400" />
              <span className="text-sm font-semibold">{property.beds}</span>
            </div>
          )}
          {property.baths && (
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-slate-600">
              <Bath size={18} className="text-slate-400" />
              <span className="text-sm font-semibold">{property.baths}</span>
            </div>
          )}
          <div className="flex items-center space-x-2 rtl:space-x-reverse text-slate-600">
            <Move size={18} className="text-slate-400" />
            <span className="text-sm font-semibold">{property.area} <span className="text-xs">م²</span></span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
