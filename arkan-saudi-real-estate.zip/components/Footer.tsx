
import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Facebook, Instagram, Twitter, Linkedin, Mail, MapPin, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  const { t, lang } = useLanguage();

  return (
    <footer className="bg-[#0b1b13] text-white pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand Info */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 rtl:space-x-reverse mb-6">
              <div className="w-10 h-10 bg-[#006c35] flex items-center justify-center rounded-lg">
                <span className="text-white font-bold text-xl">A</span>
              </div>
              <span className="text-2xl font-bold tracking-tight">
                {lang === 'ar' ? 'أركان العقارية' : 'Arkan Real Estate'}
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-8">
              {t.footerQuote}
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-[#006c35] transition-colors"><Twitter size={20} /></a>
              <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-[#006c35] transition-colors"><Facebook size={20} /></a>
              <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-[#006c35] transition-colors"><Instagram size={20} /></a>
              <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-[#006c35] transition-colors"><Linkedin size={20} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6 border-b border-white/10 pb-4">{lang === 'ar' ? 'روابط سريعة' : 'Quick Links'}</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{t.featured}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{t.cities}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{t.aboutUs}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{t.contactUs}</a></li>
            </ul>
          </div>

          {/* Locations */}
          <div>
            <h4 className="text-lg font-bold mb-6 border-b border-white/10 pb-4">{lang === 'ar' ? 'المدن الأكثر بحثاً' : 'Popular Cities'}</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{lang === 'ar' ? 'عقارات الرياض' : 'Riyadh Properties'}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{lang === 'ar' ? 'عقارات جدة' : 'Jeddah Properties'}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{lang === 'ar' ? 'عقارات الخبر' : 'Khobar Properties'}</a></li>
              <li><a href="#" className="hover:text-[#d4af37] transition-colors">{lang === 'ar' ? 'عقارات مكة' : 'Makkah Properties'}</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-bold mb-6 border-b border-white/10 pb-4">{lang === 'ar' ? 'معلومات التواصل' : 'Contact Info'}</h4>
            <ul className="space-y-6 text-slate-400">
              <li className="flex items-start space-x-4 rtl:space-x-reverse">
                <MapPin className="text-[#006c35] mt-1 shrink-0" size={20} />
                <span>{lang === 'ar' ? 'طريق الملك فهد، العليا، الرياض، المملكة العربية السعودية' : 'King Fahd Road, Olaya, Riyadh, KSA'}</span>
              </li>
              <li className="flex items-center space-x-4 rtl:space-x-reverse">
                <Phone className="text-[#006c35] shrink-0" size={20} />
                <span>+966 12 345 6789</span>
              </li>
              <li className="flex items-center space-x-4 rtl:space-x-reverse">
                <Mail className="text-[#006c35] shrink-0" size={20} />
                <span>info@arkan.sa</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <p>© {new Date().getFullYear()} {lang === 'ar' ? 'أركان العقارية. جميع الحقوق محفوظة.' : 'Arkan Real Estate. All rights reserved.'}</p>
          <div className="flex space-x-6 rtl:space-x-reverse mt-4 md:mt-0">
            <a href="#" className="hover:text-white">{lang === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}</a>
            <a href="#" className="hover:text-white">{lang === 'ar' ? 'الشروط والأحكام' : 'Terms of Service'}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
